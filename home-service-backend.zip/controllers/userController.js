exports.signupWithEmail = async (req, res) => {
  const { email, name, otp, password } = req.body;
  
};
